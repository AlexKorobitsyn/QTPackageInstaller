#!/bin/bash
sudo apt install ./postgresql_*.deb -y
