#!/bin/bash
sudo apt --fix-broken install ./postgresql-16_*.deb ./postgresql_*.deb -y
