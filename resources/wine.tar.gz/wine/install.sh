#!/bin/bash
sudo apt install ./*.deb -y
