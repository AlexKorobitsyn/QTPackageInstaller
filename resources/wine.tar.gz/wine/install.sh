#!/bin/bash
sudo apt --fix-broken install ./wine64_*.deb ./wine32_*.deb ./wine_*.deb -y
