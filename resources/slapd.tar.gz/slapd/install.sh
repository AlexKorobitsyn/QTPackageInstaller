#!/bin/bash
dpkg -i ./*.deb
