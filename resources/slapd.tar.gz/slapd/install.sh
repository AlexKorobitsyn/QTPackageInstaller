#!/bin/bash
sudo apt --fix-broken install ./*.deb -y
